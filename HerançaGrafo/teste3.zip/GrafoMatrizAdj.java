import java.util.*;
public class GrafoMatrizAdj extends Grafo{

    private int[][] matriz;
    
    public GrafoMatrizAdj(){
        super();//construtor dos metodos da herança
        this.matriz = new int[0][0]; //inicia matriz 0x0
    }

    @Override
    public void adicionarAresta(String origem, String destino){
        adicionarVertice(origem);
        aumentaGrafo();
        adicionarVertice(destino);
        aumentaGrafo();
        int i = vertmap.get(origem);
        int j = vertmap.get(destino);
        matriz[i][j] = 1;        // 1 existe aresta. 0 não existe
        matriz[j][i] = 1;
    }


    @Override
    public void removerVertice(String vertice){
        //remove o vertice e todas as arestas a ele conectadas
        if(!existeVertice(vertice)) return;
        int index_vertice = vertmap.get(vertice);
        int n = ordem();
        int[][] novamatriz = new int[n-1][n-1];
        //cria uma nova matriz sem a coluna e linha do vertice 
        int nvlin=0;
        for (int i=0;i<n;i++){
            if(i == index_vertice) continue;
            int nvcol =0;
            for(int j =0; j<n; j++){
                if (j==index_vertice) continue;
                novamatriz[nvcol][nvlin]= matriz[i][j];
                nvcol++;
            }
            nvlin++;
        }
        //nova matriz
        this.matriz = novamatriz;
        vertmap.remove(vertice);
        //atualizar o map dos vertices
        int nvchave=0;
        for (String v: vertmap.keySet()){
            vertmap.put(v,nvchave++);
        }

    }
    @Override
    public void removerAresta(String origem, String destino){
        int a = vertmap.get(origem);
        int b = vertmap.get(destino);

        matriz[a][b] = 0;
        matriz[b][a] = 0;
    }
    @Override
    public boolean existeAresta(String origem, String destino){
        //existe os vertices?
        if(!existeVertice(origem) || !existeVertice(destino)) return false;
        //existe o vertice, então verifica se existe a aresta
        if(matriz[vertmap.get(origem)][vertmap.get(destino)] == 1){
            return true;
        }else return false;

    }
    @Override
    public int tamanho(){
        //conta as arestas n repetidas
        // ou seja, conta apenas o triângulo superior ou inferior divido pela diagonal
        int tam =0;
        for(int i=0; i< matriz.length; i++){
            for(int j=i; j< matriz[i].length; j++){
                if(matriz[i][j] ==1) tam++;
            }
        }
        return tam;
    }

    @Override
    public int grau(String vertice){
        //vertice existe?
        if(!existeVertice(vertice)) return 0;
        int a = vertmap.get(vertice);
        int count=0;
        for (int qtd : matriz[a]){
            if (qtd==1) count++;
        }
        return count;
    }
    
    public void aumentaGrafo(){
        int n = ordem();
        int[][] novamatriz = new int[n][n];
        for(int i=0; i<matriz.length; i++){
            System.arraycopy(matriz[i], 0, novamatriz[i],0,matriz[i].length);
    
        }
        this.matriz = novamatriz;

    }

    @Override
    public String toString(){

        StringBuilder sb = new StringBuilder("graph {\n");
        List<String> linhasArestas = new ArrayList<>();
        List<String> chavesOrdenadas = new ArrayList<>(vertmap.keySet());

        for (int i = 0; i < chavesOrdenadas.size(); i++) {
            String v1 = chavesOrdenadas.get(i);
            for (int j = i; j < chavesOrdenadas.size(); j++) {
                String v2 = chavesOrdenadas.get(j);
                if (matriz[vertmap.get(v1)][vertmap.get(v2)]==1) {
                    linhasArestas.add("    \"" + v1 + "\" -- \"" + v2 + "\";");
                }
            }
        }

        Collections.sort(linhasArestas);
        for (String linha : linhasArestas) {
            sb.append(linha).append("\n");
        }
        sb.append("}");
        return sb.toString();
    }



}

