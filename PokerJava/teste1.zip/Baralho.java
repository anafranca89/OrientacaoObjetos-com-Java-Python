import java.util.Random;
import java.util.Collections;
import java.util.Vector;

public class Baralho extends Vector<carta> {
    private Random rand;

    public Baralho(int seed){
        for (Naipe p : Naipe.values()) {
            for (int i=2; i<=14; i++) {
                carta c = new carta(i, p);
                this.add(c);
            }
        }
        if (seed == 0) {
            rand = new Random();
        }else {
            rand = new Random(seed);
        }
        this.embaralhar();
    }

    public void embaralhar() { 
        Collections.shuffle(this, rand);
    }

    //retira a primeira carta do baralho e retorna para o 'jogador'
    public carta comprar(){
        return this.remove(0);
    }


    public void imprimir_jogada(carta[] carta) {
       for (int i = 0; i < 5; i++) {
            StringBuilder linha = new StringBuilder();
            
            for (carta c : carta) {
                String[] fatias = c.obter_fatias();
                linha.append(fatias[i]).append("  "); //pega a fatia i de cada carta para imprimir horizontalmente
            }
            
             System.out.println(linha);
        }
        for (int i = 1; i <= 5; i++) {
             System.out.printf("  (%d)    ", i);
        }
        // Imprime os índices embaixo
        System.out.println();
    }
}
