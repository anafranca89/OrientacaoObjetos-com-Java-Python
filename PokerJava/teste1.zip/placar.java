import java.util.Arrays;


public class placar {                
  

}