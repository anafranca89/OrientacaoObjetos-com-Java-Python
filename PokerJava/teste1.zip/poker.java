import java.util.Scanner;
import java.util.Vector;

public class poker{
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Semente: ");
        int seed = scan.nextInt();
        Baralho baralho = new Baralho(seed);
        System.out.print("Saldo inicial: ");
        int saldo = scan.nextInt();
        scan.nextLine(); // Limpa o buffer do scanner
        while (true) {
            if (saldo == 0) {
                System.out.println("Seu saldo acabou. Tente jogar outra vez.");
                return;
            }

            System.out.println("Saldo atual: $"+saldo);
            System.out.print("Digite o valor da aposta: of 'F' para terminar ==> ");
            String entrada = scan.nextLine();
            

            if (entrada.equals("F")) {
                System.out.println("Terminando o jogo... Parabéns você ainda tem saldo de $" + saldo);
                break;
            }
            int aposta = Integer.parseInt(entrada);
            if (aposta > saldo) {
                System.out.println("Saldo insuficiente. Tecle enter para continuar");
                scan.nextLine(); // Limpa o buffer do scanner
                continue;
            }
            // Aqui começa o jogo. 2 tentativas de troca das cartas
            // mostra 5 cartas e pergunta quais cartas o jogador quer trocar 

            for (int i = 0; i < 2; i++) {
                //mostrar cartas
                int[] carta_rolar = {1,1,1,1,1};
                baralho.embaralhar();
                Vector<carta> mao = new Vector<carta>();
                for (int j = 0; j < 5; j++) {
                    mao.add(baralho.comprar());
                }
                carta[] cartas = mao.toArray(new carta[0]);
                baralho.imprimir_jogada(cartas);
                System.out.println("Digite o número das  cartas que você deseja trocar, separadas por espaços:");
                String cartasParaTrocar = scan.nextLine();

                // Processar as cartas para trocar e atualizar a mão do jogador
            }
            //mostra cartas
            //calcula a pontuação
            System.out.println("Tecle enter para continuar"); 
            scan.nextLine(); // Limpa o buffer do scanner
            
        }
    }
}