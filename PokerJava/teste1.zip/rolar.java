import java.util.Scanner;

public class rolar {
    private int seed;
    private carta[] mao = new carta[5];
    private Random mestre;

    public void init_(int seed =0){
        this.seed = seed;

        if (this.seed != 0) {
            mestre = new Random();
            mestre.setSeed(this.seed);
        }
        for (int i = 0; i < 5; i++) { 
            if this.seed == 0 {
                this.mao[i] = new carta();
            } else {
                this.mao[i] = new carta(mestre.nextInt());
            }  
        }

    }

    public void rolar(int[] cartas_para_rolar) { 
        for (int i = 0; i < 5; i++) {
            if cartas_para_rolar[i] == 1 {
                mao[i].rolar();
            }
        }
    }

}
