import sys
from tabuleiro import Tabuleiro 
def main():

    entrada = sys.stdin.read().split()
    
    if not entrada:
        return

    dados_tabuleiro = entrada[:-1]  # Tudo menos o último item
    comandos = entrada[-1]
    #criar o tabuleiro
    lista = list(map(int, dados_tabuleiro))
    tabuleiro = Tabuleiro(lista)
    tabuleiro.printar()
    #mover o tabuleiro
    for comando in comandos:
        tabuleiro.mover(comando)
        tabuleiro.printar()
    #verificar se o tabuleiro esta resolvido
    # Verificar se o tabuleiro está resolvido
    if tabuleiro.resolvido():
        print("Posicao final: True")
    else:
        print("Posição final: False")








if __name__ == "__main__":
    main()